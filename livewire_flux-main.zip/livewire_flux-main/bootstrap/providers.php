<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\StyleProvider::class,
    App\Providers\VoltServiceProvider::class,
];
